//
//  TeleviseLiveCollectionViewCell.m
//  forwork
//
//  Created by tarena6 on 15/11/19.
//  Copyright (c) 2015年 IOS. All rights reserved.
//nickname online

#import "TeleviseLiveCollectionViewCell.h"
#import "Package/SDWebImage/UIImageView+WebCache.h"
@interface TeleviseLiveCollectionViewCell()
@property (weak, nonatomic) IBOutlet UILabel *room_nameLabel;
@property (weak, nonatomic) IBOutlet UILabel *nicknameLabel;
@property (weak, nonatomic) IBOutlet UILabel *online_Label;
@property (weak, nonatomic) IBOutlet UIImageView *room_srcImageView;

@end

@implementation TeleviseLiveCollectionViewCell

-(void)layoutSubviews{
    [super layoutSubviews];
    self.room_nameLabel.text = self.mdteleviselive.room_name;
    self.nicknameLabel.text = self.mdteleviselive.nickname;
    NSInteger number = self.mdteleviselive.online.integerValue;
    if (number<10000) {
        //@{}转字典  @[]转数组 @()把基础类型转为NSNumber
        self.online_Label.text = @(number).stringValue;
    }else{
        self.online_Label.text = [NSString stringWithFormat:@"%.1f万",number/10000.0];
    
    }
    //NSString *string = [NSString stringWithFormat:@"%@",self.mdteleviselive.online];
    //self.online_Label.text = string;
    //self.room_srcImageView.contentMode =  UIViewContentModeScaleAspectFill;
    [self.room_srcImageView setImageWithURL:[NSURL URLWithString:self.mdteleviselive.room_src] placeholderImage:[UIImage imageNamed:@"placeholder_deal"]];
}

@end
