//
//  TLData.m
//  forwork
//
//  Created by tarena6 on 15/11/17.
//  Copyright (c) 2015年 IOS. All rights reserved.
//

#import "TLData.h"
#import "MDTitle.h"
#import "MDTeleviseLive.h"
#import "MDHomePageOne.h"
#import "MDHomePageTwo.h"
#import "MDHomePageThreeRoomList.h"


@implementation TLData
static NSMutableArray *_mdtitles;
int a=0;
int b = 0;
//+(NSMutableArray *)mdtitles{
//    if (!_mdtitles) {
//        _mdtitles = [self getAndParseTitleURL:@"http://www.douyutv.com/api/v1/game?aid=android&client_sys=android&time=1445952720&auth=1a1bdb4ba653e4337e6dfdf79b4f4ab3"];
//    }
//    return _mdtitles;


//}
+(void)getAndParseTitleURLandCallback:(Callback)callback{
    /*
     NSURLRequest *request = [NSURLRequest requestWithURL:[NSURL URLWithString:@"http://www.douyutv.com/api/v1/game?aid=android&client_sys=android&time=1445952720&auth=1a1bdb4ba653e4337e6dfdf79b4f4ab3"]];
     
     NSURLSessionDataTask *dataTask = [[NSURLSession sharedSession]dataTaskWithRequest:request completionHandler:^(NSData *data, NSURLResponse *response, NSError *error) {
     NSDictionary *jsonDic = [NSJSONSerialization JSONObjectWithData:data options:0 error:nil];
     NSString *dataa = jsonDic[@"data"];
     NSString *game_name = jsonDic[@"data"][0][@"game_name"];
     NSURL *imageUrl = jsonDic[@"data"][0][@"game_src"];
     }];
     [dataTask resume];
    */
    NSURLRequest *request = [NSURLRequest requestWithURL:[NSURL URLWithString:@"http://www.douyutv.com/api/v1/game?aid=android&client_sys=android&time=1445952720&auth=1a1bdb4ba653e4337e6dfdf79b4f4ab3"]];
    NSURLSessionDataTask *dataTask= [[NSURLSession sharedSession]dataTaskWithRequest:request completionHandler:^(NSData *data, NSURLResponse *response, NSError *error) {
        NSDictionary *jsonDic = [NSJSONSerialization JSONObjectWithData:data options:0 error:nil];
        NSArray *dataArray = jsonDic[@"data"];
        NSMutableArray *mutableArray = [NSMutableArray array];
        for (NSDictionary *dataDic in dataArray) {
            MDTitle *mdtitle = [[MDTitle alloc]init];
            [mdtitle setValuesForKeysWithDictionary:dataDic];
            [mutableArray addObject:mdtitle];
            
        }
        callback(mutableArray);
    }];
    [dataTask resume];
}
//http://www.douyutv.com/api/v1/live/1?offset=0&limit=20&client_sys=ios&aid=ios&time=1427694275&auth=57d96c66116afaada1d7e471c0949d97
//栏目下直播列表
+(NSMutableArray *)nextTitleWithCateid:(NSInteger)cateid{
    NSString *pathA =[NSString stringWithFormat:@"http://www.douyutv.com/api/v1/live/%ld?",cateid];
    NSMutableDictionary *params = [NSMutableDictionary new];
    //offset需要设置
    [params setObject:@(b) forKey:@"offset"];
    [params setObject:@"20" forKey:@"limit"];
    [params setObject:@"ios" forKey:@"client_sys"];
    [params setObject:@"ios" forKey:@"aid"];
    [params setObject:@"1427694275" forKey:@"time"];
    [params setObject:@"57d96c66116afaada1d7e471c0949d97" forKey:@"auth"];
    NSMutableString *requestPath = [NSMutableString new];
    [requestPath appendString:pathA];
    [params enumerateKeysAndObjectsUsingBlock:^(id  _Nonnull key, id  _Nonnull obj, BOOL * _Nonnull stop) {
        NSString *str  = [NSString stringWithFormat:@"%@=%@&",key,obj];
        [requestPath appendString:str];
    }];
    NSURLRequest *request = [NSURLRequest requestWithURL:[NSURL URLWithString:requestPath]];
    NSData *response = [NSURLConnection sendSynchronousRequest:request returningResponse:nil error:nil];
    NSDictionary *dataDict = [NSJSONSerialization JSONObjectWithData:response options:0 error:nil];
    NSArray *array = dataDict[@"data"];
    NSMutableArray *mutableArray = [NSMutableArray new];
    for (NSDictionary *dataDic in array) {
        MDTeleviseLive *mdteleviselive = [[MDTeleviseLive alloc]init];
        mdteleviselive.game_name =  dataDic[@"game_name"];
        [mdteleviselive setValuesForKeysWithDictionary:dataDic];
        [mutableArray addObject:mdteleviselive];
    }
    b=0;
    return [mutableArray mutableCopy];
}
//栏目下直播列表 上拉加载
+(NSMutableArray *)nextUPTitleWithCateid:(NSInteger)cateid{
    NSString *pathA =[NSString stringWithFormat:@"http://www.douyutv.com/api/v1/live/%ld?",cateid];
    NSMutableDictionary *params = [NSMutableDictionary new];
    //offset需要设置
    [params setObject:@(b+20) forKey:@"offset"];
    [params setObject:@"20" forKey:@"limit"];
    [params setObject:@"ios" forKey:@"client_sys"];
    [params setObject:@"ios" forKey:@"aid"];
    [params setObject:@"1427694275" forKey:@"time"];
    [params setObject:@"57d96c66116afaada1d7e471c0949d97" forKey:@"auth"];
    NSMutableString *requestPath = [NSMutableString new];
    [requestPath appendString:pathA];
    [params enumerateKeysAndObjectsUsingBlock:^(id  _Nonnull key, id  _Nonnull obj, BOOL * _Nonnull stop) {
        NSString *str  = [NSString stringWithFormat:@"%@=%@&",key,obj];
        [requestPath appendString:str];
    }];
    NSURLRequest *request = [NSURLRequest requestWithURL:[NSURL URLWithString:requestPath]];
    NSData *response = [NSURLConnection sendSynchronousRequest:request returningResponse:nil error:nil];
    NSDictionary *dataDict = [NSJSONSerialization JSONObjectWithData:response options:0 error:nil];
    NSArray *array = dataDict[@"data"];
    NSMutableArray *mutableArray = [NSMutableArray new];
    for (NSDictionary *dataDic in array) {
        MDTeleviseLive *mdteleviselive = [[MDTeleviseLive alloc]init];
        mdteleviselive.game_name =  dataDic[@"game_name"];
        [mdteleviselive setValuesForKeysWithDictionary:dataDic];
        [mutableArray addObject:mdteleviselive];
    }
    b=b+20;
    return [mutableArray copy];
}


//首次请求直播数据
+(void)getAndParseTeleviseLiveURLandCallback:(Callback)callback{
    
    NSURLRequest *request =[NSURLRequest requestWithURL:[NSURL URLWithString:@"http://www.douyutv.com/api/v1/live?aid=android&client_sys=android&limit=20&offset=0&time=1445952900&auth=f9967e2e708e2ba1fda4188b0ecff53b"]];
    NSURLSessionDataTask *dataTask = [[NSURLSession sharedSession]dataTaskWithRequest:request completionHandler:^(NSData *data, NSURLResponse *response, NSError *error) {
        NSDictionary *jsonDic = [NSJSONSerialization JSONObjectWithData:data options:0 error:nil];
        NSArray *dataArray = jsonDic[@"data"];
        NSMutableArray *mutableArray= [NSMutableArray array];
        for (NSDictionary *dataDic in dataArray) {
            MDTeleviseLive *mdteleviselive = [[MDTeleviseLive alloc]init];
            [mdteleviselive setValuesForKeysWithDictionary:dataDic];
            [mutableArray addObject:mdteleviselive];
            //NSLog(@"%@",mdteleviselive.online);
            
        }
        callback(mutableArray);
    }];
    a=0;
    [dataTask resume];
}
//连续请求直播数据

+(void)getAndNextParseTeleviseLiveURLandCallback:(Callback)callback{
    
   
    //NSLog(@"%d",a);
    NSString *pathA =@"http://www.douyutv.com/api/v1/live?aid=android&client_sys=android&limit=20&";
    NSMutableDictionary *params = [NSMutableDictionary new];
    [params setObject:@(a+20) forKey:@"offset"];
    [params setObject:@"1445952900" forKey:@"time"];
    [params setObject:@"f9967e2e708e2ba1fda4188b0ecff53b" forKey:@"auth"];
    NSMutableString *requestPath = [NSMutableString new];
    [requestPath appendString:pathA];
    //字典自带的遍历方法，等同于forin
    [params enumerateKeysAndObjectsUsingBlock:^(id  _Nonnull key, id  _Nonnull obj, BOOL * _Nonnull stop) {
        //拼接为key=value&
        NSString *str = [NSString stringWithFormat:@"%@=%@&",key,obj];
        [requestPath appendString:str];
    }];
    a=a+20;
    NSURLRequest *request =[NSURLRequest requestWithURL:[NSURL URLWithString:requestPath]];
    NSURLSessionDataTask *dataTask = [[NSURLSession sharedSession]dataTaskWithRequest:request completionHandler:^(NSData *data, NSURLResponse *response, NSError *error) {
        NSDictionary *jsonDic = [NSJSONSerialization JSONObjectWithData:data options:0 error:nil];
        NSArray *dataArray = jsonDic[@"data"];
        NSMutableArray *mutableArray= [NSMutableArray array];
        for (NSDictionary *dataDic in dataArray) {
            MDTeleviseLive *mdteleviselive = [[MDTeleviseLive alloc]init];
            [mdteleviselive setValuesForKeysWithDictionary:dataDic];
            [mutableArray addObject:mdteleviselive];
            //NSLog(@"%@",mdteleviselive.online);
          
        }
        callback(mutableArray);
    }];
    [dataTask resume];
    
}
//+(void)getAndParseHomePageThreeURLandCallback:(Callback)callback{
//    NSURLRequest *request = [NSURLRequest requestWithURL:[NSURL URLWithString:@"http://www.douyutv.com/api/v1/channel?aid=android&client_sys=android&time=1445952300&auth=e8e993fe4515ea2b87dc265415d43abc"]];
//    NSURLSessionDataTask *dataTask = [[NSURLSession sharedSession]dataTaskWithRequest:request completionHandler:^(NSData *data, NSURLResponse *response, NSError *error) {
//        NSDictionary *jsonDic = [NSJSONSerialization JSONObjectWithData:data options:0 error:nil];
//        NSArray *dataArray = jsonDic[@"data"];
//        NSMutableArray *mutableArray = [NSMutableArray array];
//        for (NSDictionary *dataDic in dataArray) {
//            MDHomePageThree *mdhomepagethree = [[MDHomePageThree alloc]init];
//            [mdhomepagethree setValuesForKeysWithDictionary:dataDic];
//            [mutableArray addObject:mdhomepagethree];
////            NSLog(@"%@",mdhomepagethree.roomlist);
//                   }
//        callback(mutableArray);
//    }];
//    [dataTask resume];
//}
//首页请求
+(NSMutableArray *)mdhomepageone{
    NSMutableArray *mutableArray = [NSMutableArray array];
    NSURLRequest *request = [NSURLRequest requestWithURL:[NSURL URLWithString:@"http://www.douyutv.com/api/v1/slide/6?aid=android&client_sys=android&time=1445952300&auth=133c4bd7d6f6e0b25c3fccb5f9c35dbd"]];
    NSData *response = [NSURLConnection sendSynchronousRequest:request returningResponse:nil error:nil];
    NSDictionary *dataDict = [NSJSONSerialization JSONObjectWithData:response options:0 error:nil];
    NSArray *array = dataDict[@"data"];
    for (NSDictionary *dataDic in array) {
        MDHomePageOne *mdhomepageone = [[MDHomePageOne alloc]init];
        [mdhomepageone setValuesForKeysWithDictionary:dataDic];
        [mutableArray addObject:mdhomepageone];
//        NSLog(@"%@",mutableArray);
    }
    
    return [mutableArray copy];
}
+(NSMutableArray *)mdhomepagethree{
    NSMutableArray *mutableArray = [NSMutableArray array];
    NSURLRequest *request = [NSURLRequest requestWithURL:[NSURL URLWithString:@"http://www.douyutv.com/api/v1/channel?aid=android&client_sys=android&time=1445952300&auth=e8e993fe4515ea2b87dc265415d43abc"]];
    NSData *response = [NSURLConnection sendSynchronousRequest:request returningResponse:nil error:nil];
    NSDictionary *dataDict = [NSJSONSerialization JSONObjectWithData:response options:0 error:nil];
    NSArray *array = dataDict[@"data"];
    for (NSDictionary *dataDic in array) {
        MDHomePageThree *dmt = [[MDHomePageThree alloc]init];
        dmt.cate_id = dataDic[@"cate_id"];
        dmt.title = dataDic[@"title"];
        NSArray *rArray = dataDic[@"roomlist"];
        for (NSDictionary *dataRoomListDic in rArray) {
            MDHomePageThreeRoomList *roomlist = [[MDHomePageThreeRoomList alloc]init];
            roomlist.room_name = dataRoomListDic[@"room_name"];
            roomlist.nickname = dataRoomListDic[@"nickname"];
            roomlist.online = dataRoomListDic[@"online"];
            roomlist.room_src = dataRoomListDic[@"room_src"];
            [dmt.roomlist addObject:roomlist];
        }
        //[dmt setValuesForKeysWithDictionary:dataDic];
        [mutableArray addObject:dmt];
       // NSLog(@"第一个%@",mutableArray);
    }
    
    return [mutableArray copy];
}
//+(NSMutableArray *)mdhomepagethreeroomlist:(NSString *)title{
//    MDHomePageThree *dmt = [[MDHomePageThree alloc]init];
//    for (MDHomePageThree *pt in [self mdhomepagethree]) {
//        if ([pt.title isEqualToString:title]) {
//            dmt =pt;
//            break;
//        }
//    }
//    NSMutableArray *mutableArray = [NSMutableArray array];
//    for (NSDictionary *dataDic in dmt.roomlist) {
//        MDHomePageThreeRoomList *rl = [[MDHomePageThreeRoomList alloc]init];
//        [rl setValuesForKeysWithDictionary:dataDic];
//        [mutableArray addObject:rl];
//        NSLog(@"第二个%@",mutableArray);
//    }
//   
//    return [mutableArray copy];
//}
@end
