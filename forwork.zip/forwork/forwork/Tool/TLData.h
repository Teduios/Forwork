//
//  TLData.h
//  forwork
//
//  Created by tarena6 on 15/11/17.
//  Copyright (c) 2015年 IOS. All rights reserved.
//

typedef void (^Callback)(id obj);

#import <Foundation/Foundation.h>
#import "MDHomePageThree.h"
@interface TLData : NSObject
@property(nonatomic)NSInteger cate_id;

//+(NSMutableArray *)mdtitles;
//栏目请求
+(void)getAndParseTitleURLandCallback:(Callback)callback;
//栏目下直播列表 首次请求 下拉刷新
+(NSMutableArray *)nextTitleWithCateid:(NSInteger)cateid;
//栏目下直播列表 上拉加载
+(NSMutableArray *)nextUPTitleWithCateid:(NSInteger)cateid;

//首次请求直播数据 首次请求 下拉刷新
+(void)getAndParseTeleviseLiveURLandCallback:(Callback)callback;
//连续请求直播数据 上拉加载
+(void)getAndNextParseTeleviseLiveURLandCallback:(Callback)callback;

+(void)getAndParseHomePageThreeURLandCallback:(Callback)callback;
+(NSMutableArray *)mdhomepageone;


+(NSMutableArray *)mdhomepagethree;
//+(NSMutableArray *)mdhomepagethreeroomlist:(NSString *)title;
@end
