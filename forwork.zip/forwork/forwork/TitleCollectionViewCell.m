//
//  TitleCollectionViewCell.m
//  forwork
//
//  Created by tarena6 on 15/11/17.
//  Copyright (c) 2015年 IOS. All rights reserved.
//

#import "TitleCollectionViewCell.h"
#import "Package/SDWebImage/UIImageView+WebCache.h"
@interface TitleCollectionViewCell ()
@property (weak, nonatomic) IBOutlet UILabel *game_nameLabel;
@property (weak, nonatomic) IBOutlet UIImageView *game_urlImageView;
@end



@implementation TitleCollectionViewCell

//-(void)setMdtitle:(MDTitle *)mdtitle{
//    self.game_nameLabel.text = mdtitle.game_name;
//
//}

-(void)layoutSubviews{
    [super layoutSubviews];
    self.game_nameLabel.text = self.mdtitle.game_name;
    [self.game_urlImageView setImageWithURL:[NSURL URLWithString:self.mdtitle.game_src] placeholderImage:[UIImage imageNamed:@"placeholder_deal"]];
//    NSData *data =[NSData dataWithContentsOfURL:self.mdtitle.game_url];
//    UIImage *img =[[UIImage alloc]initWithData:data];
//    UIImageView *imageView = [[UIImageView alloc]initWithImage:img];
//    self.game_urlImageView = imageView;
//    NSURLSession *session = [NSURLSession sharedSession];
//    NSURLSessionDownloadTask *task = [session downloadTaskWithURL:self.mdtitle.game_url completionHandler:^(NSURL *location, NSURLResponse *response, NSError *error) {
//        
//        
//        NSString *documentPath = NSSearchPathForDirectoriesInDomains(NSDocumentDirectory, NSUserDomainMask, YES).lastObject;
//        NSString *destPath = [documentPath stringByAppendingPathComponent:@"dy.jpg"];
//        //        乾坤大挪移---
//        //        NSURL 有一个 对象方法path, 能够转换为物理路径
//        //        [[NSFileManager defaultManager] moveItemAtPath:[location path] toPath:destPath error:nil];
//        NSLog(@"path is %@", destPath);
//        //        获取主线程
//        dispatch_async(dispatch_get_main_queue(), ^{
//            UIImage *image = [UIImage imageWithContentsOfFile:destPath];
//            self.game_urlImageView.image = image;
//        });
//    }];
//    [task resume];
    
}

@end
