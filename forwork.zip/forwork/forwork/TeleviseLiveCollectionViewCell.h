//
//  TeleviseLiveCollectionViewCell.h
//  forwork
//
//  Created by tarena6 on 15/11/19.
//  Copyright (c) 2015年 IOS. All rights reserved.
//

#import <UIKit/UIKit.h>
#import "MDTeleviseLive.h"
@interface TeleviseLiveCollectionViewCell : UICollectionViewCell
@property(nonatomic,strong)MDTeleviseLive *mdteleviselive;
@end
