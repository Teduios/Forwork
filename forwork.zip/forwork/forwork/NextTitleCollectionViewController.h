//
//  NextTitleCollectionViewController.h
//  forwork
//
//  Created by z on 15/12/31.
//  Copyright © 2015年 IOS. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface NextTitleCollectionViewController : UICollectionViewController
@property (nonatomic, assign) NSInteger cateid;
@end
