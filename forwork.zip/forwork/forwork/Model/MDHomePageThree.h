//
//  MDHomePageThree.h
//  forwork
//
//  Created by tarena on 15/11/19.
//  Copyright (c) 2015年 IOS. All rights reserved.
//

#import <Foundation/Foundation.h>

@interface MDHomePageThree : NSObject
/*
 
 "error": 0,
 "data": [
 {
 "title": "竞技游戏",  ------------------------------头
 "cate_id": "homechannel_jjyx",
 "roomlist": [
 {
 "room_id": "58428",
 "room_src": "http://staticlive.douyutv.com/upload/web_pic/8/58428_1511172338_thumb.jpg", ----图片
 "cate_id": "3",
 "room_name": "OB天团解说秋季赛",  -----------------下标题
 "show_status": "1",
 "subject": "",
 "show_time": "1447754685",
 "owner_uid": "236231",
 "specific_catalog": "",
 "specific_status": "1",
 "vod_quality": "0",
 "nickname": "yyfyyf",  ------------------------房主
 "online": 1179906,         ---------------------人数
 "url": "/58428",
 "game_url": "/directory/game/DOTA2",
 "game_name": "DOTA2"
 },
 */
@property(nonatomic,strong)NSString *title;
@property(nonatomic,strong)NSString *cate_id;
@property(nonatomic,strong)NSMutableArray *roomlist;
@end
