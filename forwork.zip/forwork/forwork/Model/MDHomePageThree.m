//
//  MDHomePageThree.m
//  forwork
//
//  Created by tarena on 15/11/19.
//  Copyright (c) 2015年 IOS. All rights reserved.
//

#import "MDHomePageThree.h"

@implementation MDHomePageThree
//-(void)setValue:(id)value forUndefinedKey:(NSString *)key
//-(void)setValue:(id)value forKey:(NSString *)key{
//    if ([key isEqualToString:@"title"]) {
//        self.titl = value;
//    }
//
//
//}
- (instancetype)init
{
    self = [super init];
    if (self) {
        self.roomlist = [NSMutableArray array];
    }
    return self;
}
@end
