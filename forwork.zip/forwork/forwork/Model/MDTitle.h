//
//  MDTitle.h
//  forwork
//
//  Created by tarena6 on 15/11/17.
//  Copyright (c) 2015年 IOS. All rights reserved.
//

#import <Foundation/Foundation.h>

@interface MDTitle : NSObject
/*
 "cate_id": "1",
 "game_name": "英雄联盟",
 "short_name": "LOL",
 "game_url": "/directory/game/LOL",
 "game_src": "http://staticlive.douyutv.com/upload/game_cate/c543faae97189c529c37b7741906d5a1.jpg",
 "game_icon": "http://staticlive.douyutv.com/upload/game_cate/03f34b23c3b92aebddc99fb1a307a4df.jpg",
 "online_room": "1128",
 "online_room_ios": "58"
 
 
 
 */
@property(nonatomic)NSInteger cate_id;
//显示的名称
@property(nonatomic,copy)NSString *game_name;
@property(nonatomic,strong)NSString *short_name;
@property(nonatomic,strong)NSURL *game_url;
//显示的图片
@property(nonatomic,strong)NSString *game_src;
@property(nonatomic,strong)NSString *game_icon;
@property(nonatomic,strong)NSString *online_room;
@property(nonatomic,strong)NSString *online_room_ios;
@end
