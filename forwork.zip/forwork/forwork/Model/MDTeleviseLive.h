//
//  MDTeleviseLive.h
//  forwork
//
//  Created by tarena6 on 15/11/17.
//  Copyright (c) 2015年 IOS. All rights reserved.
//

#import <Foundation/Foundation.h>

@interface MDTeleviseLive : NSObject
/*
 "room_id": "138286",
 "room_src": "http://staticlive.douyutv.com/upload/web_pic/6/138286_1511112227_thumb.jpg",
 "cate_id": "1",
 "room_name": "White55开 双11你们有卢本伟！", ------------图下的文字
 "show_status": "1",
 "subject": "",
 "show_time": "1447241163",
 "owner_uid": "4757314",
 "specific_catalog": "wt55kai",
 "specific_status": "1",
 "vod_quality": "0",
 "nickname": "White55开解说",    -------图上文字
 "online": 1984759,                 -------人数，保留一位小数(过万)，否则不过万的，显示4位
 "url": "/wt55kai",
 "game_url": "/directory/game/LOL",
 "game_name": "英雄联盟",
 "fans": "1946369"
 */
@property(nonatomic,strong)NSString *room_id;
//图片路径
@property(nonatomic,strong)NSString *room_src;
@property(nonatomic)NSInteger cate_id;
//图下的文字，房间名称
@property(nonatomic,strong)NSString *room_name;
@property(nonatomic,strong)NSString *show_status;
@property(nonatomic,strong)NSString *subject;
@property(nonatomic,strong)NSString *show_time;
@property(nonatomic,strong)NSString *owner_uid;
@property(nonatomic,strong)NSString *specific_catalog;
@property(nonatomic,strong)NSString *specific_status;
@property(nonatomic,strong)NSString *vod_quality;
//图上的文字，解说人名称
@property(nonatomic,strong)NSString *nickname;
//房间观看人数，
@property(nonatomic,strong)NSNumber *online;
@property(nonatomic,strong)NSString *url;
@property(nonatomic,strong)NSString *game_url;
@property(nonatomic,strong)NSString *game_name;
@property(nonatomic,strong)NSString *child_id;
@property(nonatomic,strong)NSString *fans;

@end
