//
//  MDHomePageTwo.h
//  forwork
//
//  Created by tarena on 15/11/19.
//  Copyright (c) 2015年 IOS. All rights reserved.
//

#import <Foundation/Foundation.h>

@interface MDHomePageTwo : NSObject
/*
 "data": {
 "result": [
 {
 "id": "5",
 "push_ios": "0",
 "push_android": "1",
 "mobile_switch": "1",
 "url": "http://staticlive.douyutv.com/upload/room_tag/b3074875def1c0805478e1bfa5dcddd5.jpg", --------图片
 "name": "户外惊奇",   ---------------------下标题
 "status": "0",
 "sort": "0",
 "ctime": "1435646488",
 "admin": "tangyi",
 "related_id": ""
 },
 
 */
@property(nonatomic,strong)NSString *id;
@property(nonatomic,strong)NSString *push_ios;
@property(nonatomic,strong)NSString *push_android;
@property(nonatomic,strong)NSString *mobile_switch;
//图片
@property(nonatomic,strong)NSString *url;
//标题
@property(nonatomic,strong)NSString *name;
@property(nonatomic,strong)NSString *status;
@property(nonatomic,strong)NSString *sort;
@property(nonatomic,strong)NSString *ctime;
@property(nonatomic,strong)NSString *admin;
@property(nonatomic,strong)NSString *related_id;

@end
