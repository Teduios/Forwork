//
//  MDHomePageOne.h
//  forwork
//
//  Created by tarena on 15/11/19.
//  Copyright (c) 2015年 IOS. All rights reserved.
//

#import <Foundation/Foundation.h>

@interface MDHomePageOne : NSObject
/*
 "data": [
 {
 "id": "444886",
 "title": "萌妹子的战斗！",   ------------------下标题
 "pic_url": "http://staticlive.douyutv.com/upload/cms/channel/litpic/201511172313336743.jpg",   ----------图片
 "room":
 
 */
@property(nonatomic,strong)NSString *id;
//标题
@property(nonatomic,strong)NSString *title;
//图片地址
@property(nonatomic,strong)NSString *pic_url;
@property(nonatomic,strong)NSString *room;
@end
