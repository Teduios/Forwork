//
//  MDHomePageThreeRoomList.h
//  forwork
//
//  Created by tarena on 15/11/25.
//  Copyright (c) 2015年 IOS. All rights reserved.
//

#import <Foundation/Foundation.h>

@interface MDHomePageThreeRoomList : NSObject
/*"roomlist": [
 {
 "room_id": "58428",
 "room_src": "http://staticlive.douyutv.com/upload/web_pic/8/58428_1511172338_thumb.jpg", ----图片
 "cate_id": "3",
 "room_name": "OB天团解说秋季赛",  -----------------下标题
 "show_status": "1",
 "subject": "",
 "show_time": "1447754685",
 "owner_uid": "236231",
 "specific_catalog": "",
 "specific_status": "1",
 "vod_quality": "0",
 "nickname": "yyfyyf",  ------------------------房主
 "online": 1179906,         ---------------------人数
 "url": "/58428",
 "game_url": "/directory/game/DOTA2",
 "game_name": "DOTA2"
 },
 */
@property(nonatomic,strong)NSString *room_id;
//图片路径
@property(nonatomic,strong)NSString *room_src;
@property(nonatomic,strong)NSString *cate_id;
//图下的文字，房间名称
@property(nonatomic,strong)NSString *room_name;
@property(nonatomic,strong)NSString *show_status;
@property(nonatomic,strong)NSString *subject;
@property(nonatomic,strong)NSString *show_time;
@property(nonatomic,strong)NSString *owner_uid;
@property(nonatomic,strong)NSString *specific_catalog;
@property(nonatomic,strong)NSString *specific_status;
@property(nonatomic,strong)NSString *vod_quality;
//图上的文字，解说人名称
@property(nonatomic,strong)NSString *nickname;
//房间观看人数，
@property(nonatomic,strong)NSNumber *online;
@property(nonatomic,strong)NSString *url;
@property(nonatomic,strong)NSString *game_url;
@property(nonatomic,strong)NSString *game_name;

@end
