//
//  NextTitleCollectionViewCell.h
//  forwork
//
//  Created by z on 15/12/31.
//  Copyright © 2015年 IOS. All rights reserved.
//

#import <UIKit/UIKit.h>
#import "MDTeleviseLive.h"
@interface NextTitleCollectionViewCell : UICollectionViewCell
@property(nonatomic,strong)MDTeleviseLive *mdteleviselive;
@end
