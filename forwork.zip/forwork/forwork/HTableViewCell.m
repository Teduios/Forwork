//
//  HTableViewCell.m
//  forwork
//
//  Created by tarena on 15/11/11.
//  Copyright (c) 2015年 IOS. All rights reserved.
//

#import "HTableViewCell.h"
#import "Package/SDWebImage/UIImageView+WebCache.h"
@interface HTableViewCell()
@property (weak, nonatomic) IBOutlet UILabel *titleLabel;
@property (weak, nonatomic) IBOutlet UILabel *room_nameLabelOne;
@property (weak, nonatomic) IBOutlet UILabel *room_nameLabelTwo;
@property (weak, nonatomic) IBOutlet UILabel *room_nameLabelThree;
@property (weak, nonatomic) IBOutlet UILabel *room_nameLabelFour;
@property (weak, nonatomic) IBOutlet UILabel *nicknameLabelOne;
@property (weak, nonatomic) IBOutlet UILabel *nicknameLabelTwo;
@property (weak, nonatomic) IBOutlet UILabel *nicknameLabelThree;
@property (weak, nonatomic) IBOutlet UILabel *nicknameLabelFour;
@property (weak, nonatomic) IBOutlet UILabel *onlineLabelOne;
@property (weak, nonatomic) IBOutlet UILabel *onlineLabelTwo;
@property (weak, nonatomic) IBOutlet UILabel *onlineLabelThree;
@property (weak, nonatomic) IBOutlet UILabel *onlineLabelFour;
@property (weak, nonatomic) IBOutlet UIImageView *room_srcImageViewOne;
@property (weak, nonatomic) IBOutlet UIImageView *room_srcImageViewTwo;
@property (weak, nonatomic) IBOutlet UIImageView *room_srcImageViewThree;
@property (weak, nonatomic) IBOutlet UIImageView *room_srcImageViewFour;


@end

@implementation HTableViewCell

- (void)awakeFromNib {
    // Initialization code
}

- (void)setSelected:(BOOL)selected animated:(BOOL)animated {
    [super setSelected:selected animated:animated];

    // Configure the view for the selected state
}
-(void)layoutSubviews{
        [super layoutSubviews];
        self.titleLabel.text = self.mdhomepagethree.title;
//      for (int i=0; i<4; i++) {
        MDHomePageThreeRoomList *roomlist = [[MDHomePageThreeRoomList alloc]init];
        roomlist = self.mdhomepagethree.roomlist[0];
        self.room_nameLabelOne.text = roomlist.room_name;
        self.nicknameLabelOne.text = roomlist.nickname;
        NSInteger number = roomlist.online.integerValue;
        if (number<10000) {
        //@{}转字典  @[]转数组 @()把基础类型转为NSNumber
            self.onlineLabelOne.text = @(number).stringValue;
        }else{
            self.onlineLabelOne.text = [NSString stringWithFormat:@"%.1f万",number/10000.0];
            
        }
       // NSString *string = [NSString stringWithFormat:@"%@",roomlist.online];
        //self.onlineLabelOne.text = string;
        [self.room_srcImageViewOne setImageWithURL:[NSURL URLWithString:roomlist.room_src] placeholderImage:[UIImage imageNamed:@"placeholder_deal"]];
        
        MDHomePageThreeRoomList *roomlist1 = [[MDHomePageThreeRoomList alloc]init];
        roomlist1 = self.mdhomepagethree.roomlist[1];
        self.room_nameLabelTwo.text = roomlist1.room_name;
        self.nicknameLabelTwo.text = roomlist1.nickname;
        NSInteger number1 = roomlist1.online.integerValue;
        if (number1<10000) {
            self.onlineLabelTwo.text = @(number1).stringValue;
        }else{
            self.onlineLabelTwo.text = [NSString stringWithFormat:@"%.1f万",number1/10000.0];
        }
        //NSString *string1 = [NSString stringWithFormat:@"%@",roomlist1.online];
        //self.onlineLabelTwo.text = string1;
        [self.room_srcImageViewTwo setImageWithURL:[NSURL URLWithString:roomlist1.room_src] placeholderImage:[UIImage imageNamed:@"placeholder_deal"]];
        
        MDHomePageThreeRoomList *roomlist2 = [[MDHomePageThreeRoomList alloc]init];
        roomlist2 = self.mdhomepagethree.roomlist[2];
        self.room_nameLabelThree.text = roomlist2.room_name;
        self.nicknameLabelThree.text = roomlist2.nickname;
        NSInteger number2 = roomlist2.online.integerValue;
        if (number2<10000) {
            self.onlineLabelThree.text = @(number2).stringValue;
        }else{
            self.onlineLabelThree.text = [NSString stringWithFormat:@"%.1f万",number2/10000.0];
        }
        //NSString *string2= [NSString stringWithFormat:@"%@",roomlist2.online];
        //self.onlineLabelThree.text = string2;
        [self.room_srcImageViewThree setImageWithURL:[NSURL URLWithString:roomlist2.room_src] placeholderImage:[UIImage imageNamed:@"placeholder_deal"]];
        
        MDHomePageThreeRoomList *roomlist3 = [[MDHomePageThreeRoomList alloc]init];
        roomlist3 = self.mdhomepagethree.roomlist[3];
    //NSString *stra = [roomlist3.room_name UTF8String];
        self.room_nameLabelFour.text = roomlist3.room_name;
        self.nicknameLabelFour.text = roomlist3.nickname;
        NSInteger number3 =roomlist3.online.integerValue;
        if (number3<10000) {
            self.onlineLabelFour.text = @(number3).stringValue;
        }else{
            self.onlineLabelFour.text = [NSString stringWithFormat:@"%.1f万",number3/10000.0];
        }
        //NSString *string3 = [NSString stringWithFormat:@"%@",roomlist.online];
        //self.onlineLabelFour.text = string3;
        [self.room_srcImageViewFour setImageWithURL:[NSURL URLWithString:roomlist3.room_src] placeholderImage:[UIImage imageNamed:@"placeholder_deal"]];
       // NSLog(@"%@",roomlist3.room_name);
//    }
    
    

}

@end
