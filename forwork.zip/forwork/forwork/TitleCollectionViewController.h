//
//  TitleCollectionViewController.h
//  forwork
//
//  Created by tarena on 15/11/11.
//  Copyright (c) 2015年 IOS. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface TitleCollectionViewController : UICollectionViewController


@end
