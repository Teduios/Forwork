//
//  NextTitleCollectionViewController.m
//  forwork
//
//  Created by z on 15/12/31.
//  Copyright © 2015年 IOS. All rights reserved.
//

#import "NextTitleCollectionViewController.h"
#import "NextTitleCollectionViewCell.h"
#import "TLData.h"
#import "MJRefresh.h"
@interface NextTitleCollectionViewController ()
@property(nonatomic,strong)NSMutableArray *mutableArray;
@end

@implementation NextTitleCollectionViewController

static NSString * const reuseIdentifier = @"Cell";
-(void)viewWillDisappear:(BOOL)animated{
    [super viewWillDisappear:YES];
    self.tabBarController.tabBar.hidden = NO;
}
//-(void)viewDidDisappear:(BOOL)animated{
//    [super viewDidDisappear:YES];
//    self.tabBarController.tabBar.hidden = NO;
//
//}
- (void)viewDidLoad {
    [super viewDidLoad];
    //self.navigationController.hidesBottomBarWhenPushed =YES;
    self.tabBarController.tabBar.hidden =YES;
   // self.hidesBottomBarWhenPushed=NO;
    
    self.mutableArray = [TLData nextTitleWithCateid:self.cateid];
    //上拉刷新
    self.collectionView.header = [MJRefreshNormalHeader headerWithRefreshingBlock:^{
            self.mutableArray = [TLData nextTitleWithCateid:self.cateid];
            dispatch_async(dispatch_get_main_queue(), ^{
                [self.collectionView reloadData];
                [self.collectionView.header endRefreshing];
            });
        
    }];
    //下拉加载
#warning 没弄好
    self.collectionView.footer = [MJRefreshBackNormalFooter footerWithRefreshingBlock:^{
        
            [self.mutableArray addObjectsFromArray: [TLData nextUPTitleWithCateid: self.cateid]];
            dispatch_async(dispatch_get_main_queue(), ^{
                [self.collectionView reloadData];
                [self.collectionView.footer endRefreshing];
            });
        
    }];
    [self.collectionView.header beginRefreshing];

}

- (void)didReceiveMemoryWarning {
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}



#pragma mark - Navigation


#pragma mark <UICollectionViewDataSource>



- (NSInteger)collectionView:(UICollectionView *)collectionView numberOfItemsInSection:(NSInteger)section {

    return self.mutableArray.count;
}

- (UICollectionViewCell *)collectionView:(UICollectionView *)collectionView cellForItemAtIndexPath:(NSIndexPath *)indexPath {
    NextTitleCollectionViewCell *cell = [collectionView dequeueReusableCellWithReuseIdentifier:@"Cell" forIndexPath:indexPath];
    cell.mdteleviselive = self.mutableArray[indexPath.row];
    //self.title = cell.mdteleviselive.game_name;
    [cell setNeedsLayout];
    
    return cell;
}
- (UIEdgeInsets)collectionView:(UICollectionView *)collectionView layout:(UICollectionViewLayout *)collectionViewLayout insetForSectionAtIndex:(NSInteger)section{
    return UIEdgeInsetsMake(10, 10, 10, 10);
}
- (CGFloat)collectionView:(UICollectionView *)collectionView layout:(UICollectionViewLayout *)collectionViewLayout minimumLineSpacingForSectionAtIndex:(NSInteger)section{
    return 10;
}
- (CGFloat)collectionView:(UICollectionView *)collectionView layout:(UICollectionViewLayout *)collectionViewLayout minimumInteritemSpacingForSectionAtIndex:(NSInteger)section{
    return 10;
}
- (CGSize)collectionView:(UICollectionView *)collectionView layout:(UICollectionViewLayout *)collectionViewLayout sizeForItemAtIndexPath:(NSIndexPath *)indexPath{
    CGFloat width=(self.view.bounds.size.width-3*10)/2;
    // 350 * 235
    CGFloat height= width*235/350;
    return CGSizeMake(width, height);
}
#pragma mark <UICollectionViewDelegate>

/*
// Uncomment this method to specify if the specified item should be highlighted during tracking
- (BOOL)collectionView:(UICollectionView *)collectionView shouldHighlightItemAtIndexPath:(NSIndexPath *)indexPath {
	return YES;
}
*/

/*
// Uncomment this method to specify if the specified item should be selected
- (BOOL)collectionView:(UICollectionView *)collectionView shouldSelectItemAtIndexPath:(NSIndexPath *)indexPath {
    return YES;
}
*/

/*
// Uncomment these methods to specify if an action menu should be displayed for the specified item, and react to actions performed on the item
- (BOOL)collectionView:(UICollectionView *)collectionView shouldShowMenuForItemAtIndexPath:(NSIndexPath *)indexPath {
	return NO;
}

- (BOOL)collectionView:(UICollectionView *)collectionView canPerformAction:(SEL)action forItemAtIndexPath:(NSIndexPath *)indexPath withSender:(id)sender {
	return NO;
}

- (void)collectionView:(UICollectionView *)collectionView performAction:(SEL)action forItemAtIndexPath:(NSIndexPath *)indexPath withSender:(id)sender {
	
}
*/

@end
