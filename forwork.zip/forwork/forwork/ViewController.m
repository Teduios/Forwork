//
//  ViewController.m
//  forwork
//
//  Created by tarena2 on 15/10/30.
//  Copyright (c) 2015年 IOS. All rights reserved.
//

#import "ViewController.h"

@interface ViewController ()<UIScrollViewDelegate>

@property(nonatomic,strong)UIScrollView *scrollView;



@end

@implementation ViewController

- (void)viewDidLoad {
    [super viewDidLoad];
    self.view.frame = CGRectMake(0, 0, self.view.frame.size.width, self.view.frame.size.height/3);
    self.scrollView = [[UIScrollView alloc]init];
    self.scrollView.frame = self.view.bounds;
    self.scrollView.pagingEnabled = YES;
    self.scrollView.showsHorizontalScrollIndicator = NO;
    self.scrollView.showsVerticalScrollIndicator = NO;
    
    [self.view addSubview:self.scrollView];
    //占位图片
    NSArray *ads = @[@"welcome1",@"welcome1",@"welcome1",@"welcome1",@"welcome1"];
    //scrollview
    for (int i =0; i<ads.count; i++) {
        UIImage *image = [UIImage imageNamed:ads[i]];
        UIImageView *imageView = [[UIImageView alloc]initWithImage:image];
        CGRect frame = self.scrollView.frame;
        frame.origin.x = i*frame.size.width;
        frame.origin.y = 0;
        imageView.frame = frame;
        [self.scrollView addSubview:imageView];
    }
    CGSize size = self.scrollView.frame.size;
    size.width *=ads.count;
    self.scrollView.contentSize = size;
    self.scrollView.delegate = self;
    //config the page control
    UIPageControl *pageControl = [[UIPageControl alloc]init];
    pageControl.frame = CGRectMake(0, self.view.frame.size.height - 40, self.view.frame.size.width, 20);
    pageControl.numberOfPages = ads.count;
    pageControl.currentPage = 0;
    pageControl.userInteractionEnabled = NO;
    self.pageControl = pageControl;
    [self.view addSubview:pageControl];
    

}
- (void)scrollViewDidScroll:(UIScrollView *)scrollView{
    self.pageControl.currentPage = round(scrollView.contentOffset.x / scrollView.frame.size.width);
    
}


#pragma mark - Table view data source



@end
