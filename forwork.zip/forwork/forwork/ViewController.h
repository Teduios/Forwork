//
//  ViewController.h
//  forwork
//
//  Created by tarena2 on 15/10/30.
//  Copyright (c) 2015年 IOS. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface ViewController : UIViewController

@property(nonatomic,weak)UIPageControl *pageControl;
@end

