//
//  PlayViewController.m
//  forwork
//
//  Created by z on 16/1/7.
//  Copyright © 2016年 IOS. All rights reserved.
//

#import "PlayViewController.h"

@implementation PlayViewController
-(void)viewDidLoad{
    [super viewDidLoad];
    self.view.backgroundColor = [UIColor whiteColor];
    [self setupUI];
    [self.player play];
}
-(void)dealloc{
    
}
#pragma mark -私有方法
-(void)setupUI{
    //创建播放器层
    AVPlayerLayer *playerLayer = [AVPlayerLayer playerLayerWithPlayer:self.player];
    playerLayer.frame = self.container.frame;
    playerLayer.videoGravity = AVLayerVideoGravityResizeAspect;//视频填充模式
    [self.container.layer addSublayer:playerLayer];

}
/*
 初始化播放器
 @return 播放器对象
 */
-(AVPlayer *)player{
    if (!_player) {
        NSString *filePath = [[NSBundle mainBundle]pathForResource:@"广告" ofType:@"mov"];
        //NSString *str = @"http://flv2.bn.netease.com/tvmrepo/2016/1/G/U/EBBPUCQGU/SD/EBBPUCQGU-mobile.mp4";
        NSURL *url = [NSURL fileURLWithPath:filePath];
       // NSURL *url = [NSURL URLWithString:str];
        //创建AVAsset对象
        AVAsset *asset = [AVURLAsset URLAssetWithURL:url options:nil];
        //创建AVPlayerItem
        AVPlayerItem *item = [AVPlayerItem playerItemWithAsset:asset];
        _player = [AVPlayer playerWithPlayerItem:item];
    }
    return _player;
}
/*
 *根据视频索引取得AVPlayerItem对象
 *@param videoIndex视频顺序索引
 *@return AVPlayItem对象
 */
//-(AVPlayerItem *)getPlayItem:(int)videoIndex{
//   // NSString *urlStr = [NSString stringWithFormat:@"http://192.168.1.161/%i,mp4",videoIndex];
//    NSString *urlStr = @"http://flv2.bn.netease.com/videolib3/1601/07/RcdmY0823/SD/RcdmY0823-mobile.mp4";
//    urlStr = [urlStr stringByAddingPercentEscapesUsingEncoding:NSUTF8StringEncoding];
//    NSURL *url =[NSURL URLWithString:urlStr];
//    AVPlayerItem *playerItem = [AVPlayerItem playerItemWithURL:url];
//    return playerItem;
//}
#pragma mark - 通知
/*
 添加播放器通知
 
 */
//-(void)addNotification{
//    //给AVPlayerItem添加播放完成通知
//    [[NSNotificationCenter defaultCenter]addObserver:self selector:@selector(playbackFinished:) name:AVPlayerItemDidPlayToEndTimeNotification object:self.player.currentItem];
//    
//}
-(void)removeNotification{
    [[NSNotificationCenter defaultCenter]removeObserver:self];

}
/*
 播放完成通知
 @param notification
 
 */
//-(void)playbackFinished:(NSNotification *)notification{
//    NSLog(@"视频播放完成。");
//
//}
#pragma mark - 监控
/*
 给AVPlayerItem 添加监控
 @param playerItem AVPlayerItem对象
 */
-(void)addObserverToPlayerItem:(AVPlayerItem *)playerItem{
    // 监控状态属性,注意AVPlayer也有一个status属性，通过监控它的status也可以获得播放状态
    [playerItem addObserver:self forKeyPath:@"status" options:NSKeyValueObservingOptionNew context:nil];
    //监控网络加载情况属性
    [playerItem addObserver:self forKeyPath:@"loadedTimeRanges" options:NSKeyValueObservingOptionNew context:nil];

}
/*通过kvo监控播放器状态*/
#pragma  mark -UI事件
/*
    点击播放／暂停按钮
    @param sender
 */
- (IBAction)playClick:(UIButton *)sender {
    if (self.player.rate ==0) {//说明是暂停
        [sender setImage:[UIImage imageNamed:@"btn_player_pause"] forState:UIControlStateNormal];
        [self.player play];
    }else if (self.player.rate ==1){
        [self.player pause];
        [sender setImage:[UIImage imageNamed:@"btn_player_play"] forState:UIControlStateNormal];
    
    }
    
}
- (IBAction)backUpView:(UIButton *)sender {
    [self dismissViewControllerAnimated:YES completion:nil];
    
}
//设置全屏
- (IBAction)fullView:(UIButton *)sender {
     self.container.frame = self.view.frame ;
    AVPlayerLayer *playerLayer = [AVPlayerLayer playerLayerWithPlayer:self.player];
    playerLayer.frame = self.container.frame;
    
}




@end
