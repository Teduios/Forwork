//
//  MainTableViewController.m
//  forwork
//
//  Created by tarena on 15/11/9.
//  Copyright (c) 2015年 IOS. All rights reserved.
//

#import "MainTableViewController.h"
#import "ViewController.h"
#import "HTableViewCell.h"
#import "TLData.h"
#import "Package/SDWebImage/UIImageView+WebCache.h"
#import "MDHomePageOne.h"
@interface MainTableViewController ()<UIScrollViewDelegate>
@property(nonatomic,weak)ViewController *viewController;
@property(nonatomic,retain)UIPageControl *pageControl;
@property(nonatomic,retain)UIScrollView *scrollView;
@property(nonatomic,strong)NSMutableArray *mutableArray;
@property(nonatomic,strong)NSMutableArray *pageonemutableArray;
@end

@implementation MainTableViewController

- (void)viewDidLoad {
    [super viewDidLoad];
   
    //修改tabbaritem选中图片,:在storyboard中设置没效果
    self.navigationController.tabBarItem.selectedImage = [[UIImage imageNamed:@"btn_home_selected"] imageWithRenderingMode:UIImageRenderingModeAlwaysOriginal];
    //修改title中的颜色
    [self.navigationController.tabBarItem setTitleTextAttributes:[NSDictionary dictionaryWithObjectsAndKeys:[UIColor orangeColor],NSForegroundColorAttributeName, nil] forState:UIControlStateSelected];
    //[[UITabBarItem appearance] setTitleTextAttributes:[NSDictionary dictionaryWithObjectsAndKeys:
//                                                       titleHighlightedColor, UITextAttributeTextColor,
//                                                       nil] forState:UIControlStateSelected];
    
    
//    [TLData getAndParseHomePageThreeURLandCallback:^(id obj) {
//        self.mutableArray = obj;
//        dispatch_async(dispatch_get_main_queue(), ^{
//            [self.tableView reloadData];
//        });
//    }];
    self.mutableArray = [TLData mdhomepagethree];
    self.pageonemutableArray = [TLData mdhomepageone];
    [self.tableView reloadData];
    //self.title= @"占位文字";
    //ViewController *headerViewController = [[ViewController alloc]init];
    UIImageView *headerView = [[UIImageView alloc]initWithFrame:CGRectMake(0, 0, self.tableView.frame.size.width/2, 200)];
    
    //headerView.image = [UIImage imageNamed:@"welcome1"];
    //self.tableView.tableHeaderView.frame = headerViewController.view.frame ;
    //self.tableView.tableHeaderView = headerViewController.view;
    //self.tableView.autoresizesSubviews = YES;
    self.tableView.tableHeaderView.backgroundColor = [UIColor blackColor];
    
    self.tableView.tableHeaderView = headerView;
    
    
    
    
    self.scrollView = [[UIScrollView alloc]init];
    self.scrollView.frame = headerView.bounds;
    self.scrollView.pagingEnabled = YES;
    self.scrollView.showsHorizontalScrollIndicator = NO;
    self.scrollView.showsVerticalScrollIndicator = NO;
    [self.scrollView addSubview:headerView];
    [self.view addSubview:self.scrollView];
    //占位图片
    NSArray *ads = @[@"welcome1",@"welcome1",@"welcome1",@"welcome1",@"welcome1",@"welcome1"];
    //scrollview
    for (int i =0; i<ads.count; i++) {
        
        UIImage *image = [UIImage imageNamed:ads[i]];
        //UIImageView *imageView1= [[UIImageView alloc]initWithImage:image];
        UIImageView *imageView = [[UIImageView alloc]init];
        MDHomePageOne *mdhomepageone = [[MDHomePageOne alloc]init];
        mdhomepageone=self.pageonemutableArray[i];
        
        
        [imageView setImageWithURL:[NSURL URLWithString:mdhomepageone.pic_url] placeholderImage:[UIImage imageNamed:@"placeholder_deal"]];
        
        CGRect frame = self.scrollView.frame;
        frame.origin.x = i*frame.size.width;
        frame.origin.y = 0;
        imageView.frame = frame;
        UILabel *label = [[UILabel alloc]initWithFrame:CGRectMake(0, 160, 200, 40)];
        
        
        //label.textAlignment = NSTextAlignmentLeft;
        label.textColor = [UIColor whiteColor];
        label.text = mdhomepageone.title;
       // NSLog(@"%@",label.text);
        
        
        [imageView addSubview:label];
        [self.scrollView addSubview:imageView];
    }
    CGSize size = self.scrollView.frame.size;
    size.width *=ads.count;
    self.scrollView.contentSize = size;
    self.scrollView.delegate = self;
    //config the page control
    UIPageControl *pageControl = [[UIPageControl alloc]init];
    pageControl.frame = CGRectMake(0, headerView.frame.size.height-40, self.view.frame.size.width, 20);
    pageControl.numberOfPages = ads.count;
    pageControl.currentPage = 0;
    pageControl.userInteractionEnabled = NO;
    self.pageControl = pageControl;
    [self.view addSubview:pageControl];
   
//    [self.tableView registerNib:[UINib nibWithNibName:@"TitleViewController" bundle:nil] forCellReuseIdentifier:@"Cell"];
//    [self.tableView registerNib:[UINib nibWithNibName:@"NewsCell" bundle:nil] forCellReuseIdentifier:@"Cell"];
    [self.tableView registerNib:[UINib nibWithNibName:@"HTableViewCell" bundle:nil] forCellReuseIdentifier:@"Cell"];
    
    UISwipeGestureRecognizer *swipeLeft = [[UISwipeGestureRecognizer alloc] initWithTarget:self action:@selector(tappedRightButton:)];
    [swipeLeft setDirection:UISwipeGestureRecognizerDirectionLeft];
    [self.view addGestureRecognizer:swipeLeft];
    UISwipeGestureRecognizer *swipeRight = [[UISwipeGestureRecognizer alloc] initWithTarget:self action:@selector(tappedLeftButton:)];
    [swipeRight setDirection:UISwipeGestureRecognizerDirectionRight];
    [self.view addGestureRecognizer:swipeRight];
}

- (IBAction) tappedRightButton:(id)sender
{
    NSUInteger selectedIndex = [self.tabBarController selectedIndex];
    NSArray *aryViewController = self.tabBarController.viewControllers;
    if (selectedIndex < aryViewController.count - 1) {
        UIView *fromView = [self.tabBarController.selectedViewController view];
        UIView *toView = [[self.tabBarController.viewControllers objectAtIndex:selectedIndex + 1] view];
        [UIView transitionFromView:fromView toView:toView duration:0.5f options:UIViewAnimationOptionTransitionFlipFromRight completion:^(BOOL finished) {
            if (finished) {
                [self.tabBarController setSelectedIndex:selectedIndex + 1];
                }
            }];
        }
}
- (IBAction) tappedLeftButton:(id)sender
{
    NSUInteger selectedIndex = [self.tabBarController selectedIndex];
    if (selectedIndex > 0) {
        UIView *fromView = [self.tabBarController.selectedViewController view];
        UIView *toView = [[self.tabBarController.viewControllers objectAtIndex:selectedIndex - 1] view];
        [UIView transitionFromView:fromView toView:toView duration:0.5f options:UIViewAnimationOptionTransitionFlipFromLeft completion:^(BOOL finished) {
            if (finished) {
                [self.tabBarController setSelectedIndex:selectedIndex - 1];
                }
            }];
        }
}



- (void)didReceiveMemoryWarning {
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}

#pragma mark - Table view data source
-(NSInteger)numberOfSectionsInTableView:(UITableView *)tableView{
    return 1;
}
-(NSInteger)tableView:(UITableView *)tableView numberOfRowsInSection:(NSInteger)section{
    return self.mutableArray.count;
}
-(UITableViewCell *)tableView:(UITableView *)tableView cellForRowAtIndexPath:(NSIndexPath *)indexPath{
    //因为提早已经注册过，所以此处只需要按照注册时候的identifier取就可以了
    //同时，搭配注册这种方式时，第二个forIndexPath参数可以不用删掉了
    HTableViewCell *cell = [tableView dequeueReusableCellWithIdentifier:@"Cell"];
//    if (cell == nil) {
//        cell = [[HTableViewCell alloc]initWithStyle:UITableViewCellStyleDefault reuseIdentifier:@"Cell"];
//    }
//    [cell.button setTitle:@"WD" forState:UIControlStateNormal];
//    cell.button.backgroundColor = [UIColor redColor];
//    NSString *string = [NSString stringWithFormat:@"%d",indexPath.row];
    //cell.textLabel.text = string;
    cell.mdhomepagethree = self.mutableArray[indexPath.row];
    //cell.mdhomepagethreeroomlist =[TLData mdhomepagethreeroomlist:cell.mdhomepagethree.title][0];
    return cell;

}

//cell 的高
-(CGFloat)tableView:(UITableView *)tableView heightForRowAtIndexPath:(NSIndexPath *)indexPath{

    return self.view.frame.size.height/2.6;
}
//头视图的高
-(CGFloat)tableView:(UITableView *)tableView heightForHeaderInSection:(NSInteger)section{
   // return self.view.frame.size.height/3;
    return 20;
    }
//-(UIView *)tableView:(UITableView *)tableView viewForHeaderInSection:(NSInteger)section{
//
//    return self.viewController.view;
//}

- (void)scrollViewDidScroll:(UIScrollView *)scrollView{
    scrollView.backgroundColor = [UIColor blackColor];
    self.pageControl.currentPage = round(scrollView.contentOffset.x / scrollView.frame.size.width);
    
}


@end
