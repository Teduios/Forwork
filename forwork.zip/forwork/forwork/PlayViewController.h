//
//  PlayViewController.h
//  forwork
//
//  Created by z on 16/1/7.
//  Copyright © 2016年 IOS. All rights reserved.
//

#import <UIKit/UIKit.h>
#import <AVFoundation/AVFoundation.h>
@interface PlayViewController : UIViewController
@property(nonatomic,strong)AVPlayer *player;//播放器对象
@property (weak, nonatomic) IBOutlet UIView *container;//播放器容器
@property (weak, nonatomic) IBOutlet UIButton *playOrPause;//播放/暂停按钮

@end
